package com.example.tomato.wyw_6;

/**
 * Created by tomato on 2016-05-22.
 */
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import com.kakao.network.ErrorResult;
import com.kakao.usermgmt.UserManagement;
import com.kakao.usermgmt.callback.LogoutResponseCallback;
import com.kakao.usermgmt.response.model.UserProfile;
import com.kakao.util.helper.log.Logger;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    DBHelper helper;
    SQLiteDatabase db;

    private WebView mWebView;
    private Button saveCheck;
    private Button saveInfo;
    private Button logOut;
    private TextView Score;
    private CheckBox checkScholar;
    private CheckBox checkRecruit;
    private CheckBox checkCancle;
    private CheckBox checkMaterials;
    private CheckBox checkForeign;
    private EditText textName;
    private EditText textGrade;
    private EditText textScore;
    private EditText textPoints;
    private Spinner spinner;



    String urlsource = "http://keeper.cse.pusan.ac.kr/WYW_search.html";
    String url = "http://keeper.cse.pusan.ac.kr/WYW_search.html";//http://keeper.cse.pusan.ac.kr/WYW_search.html

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //toiec score
        Score = (TextView)findViewById(R.id.textScore);
        Spinner s = (Spinner)findViewById(R.id.spinner);

        //webview
        mWebView = (WebView)findViewById(R.id.webview);
        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);

        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                //String urlString = mWebView.getUrl().toString();
                //url_String.setText(urlString);
            }
        });

        mWebView.loadUrl(urlsource);
        //mWebView.loadUrl("http://pusan.ac.kr");

        //mWebView.setHorizontalScrollBarEnabled(false);
        //mWebView.setVerticalScrollBarEnabled(false);

        checkScholar = (CheckBox)findViewById(R.id.checkScholar);
        checkRecruit = (CheckBox)findViewById(R.id.checkRecruit);
        checkCancle = (CheckBox)findViewById(R.id.checkCancle);
        checkMaterials = (CheckBox)findViewById(R.id.checkMaterials);
        checkForeign = (CheckBox)findViewById(R.id.checkForeign);
        saveCheck = (Button)findViewById(R.id.saveCheck);

        //textName = (EditText)findViewById(R.id.textName);
        textGrade = (EditText)findViewById(R.id.textGrade);
        textScore = (EditText)findViewById(R.id.textScore);
        textPoints = (EditText)findViewById(R.id.textPoints);
        saveInfo = (Button)findViewById(R.id.saveInfo);
        logOut = (Button)findViewById(R.id.logout);
        spinner = (Spinner)findViewById(R.id.spinner);

        helper = new DBHelper(MainActivity.this, "person.db", null, 1);
        db = helper.getWritableDatabase();
        helper.onCreate(db);

        TabHost host = (TabHost)findViewById(R.id.tabHost);
        host.setup();

        //Tab 1
        TabHost.TabSpec spec = host.newTabSpec("Tab One");
        spec.setContent(R.id.tab1);
        spec.setIndicator("", ResourcesCompat.getDrawable(getResources(), R.drawable.check, null));
        host.addTab(spec);

        //Tab 2
        spec = host.newTabSpec("Tab Two");
        spec.setContent(R.id.tab2);
        spec.setIndicator("", ResourcesCompat.getDrawable(getResources(), R.drawable.search, null));
        host.addTab(spec);

        //Tab 3
        spec = host.newTabSpec("Tab Three");
        spec.setContent(R.id.tab3);
        spec.setIndicator("", ResourcesCompat.getDrawable(getResources(), R.drawable.info, null));
        host.addTab(spec);

        //Toast.makeText(MainActivity.this, "start", Toast.LENGTH_LONG).show();
        //Log.i("db", "start~~~~~~~~~~~~ ");

        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickLogout();
            }
        });
        saveCheck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                AlertDialog.Builder alert_confirm = new AlertDialog.Builder(MainActivity.this);
                alert_confirm.setMessage("정보를 저장하시겠습니까?").setCancelable(false).setPositiveButton("확인",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //고유 아이디!
                                String checkcheck = "";
//장학금(checkScholar), 취업(checkRecruit), 휴강(checkCancle), 수업자료(checkMaterials), 해외(checkForeign)
                                if(checkScholar.isChecked()) checkcheck+="1";
                                else checkcheck+="0";
                                if(checkRecruit.isChecked()) checkcheck+="1";
                                else checkcheck+="0";
                                if(checkCancle.isChecked()) checkcheck+="1";
                                else checkcheck+="0";
                                if(checkMaterials.isChecked()) checkcheck+="1";
                                else checkcheck+="0";
                                if(checkForeign.isChecked()) checkcheck+="1";
                                else checkcheck+="0";

                                update(checkcheck);

                                select(); //update check!
                                Toast.makeText(MainActivity.this, "저장되었습니다.", Toast.LENGTH_LONG).show();
                                //web알림 http://keeper.cse.pusan.ac.kr/WYW_search.html

                            }
                        }).setNegativeButton("취소",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // 'No'
                                Toast.makeText(MainActivity.this, "취소되었습니다.", Toast.LENGTH_LONG).show();
                                return;
                            }
                        });
                AlertDialog alert = alert_confirm.create();
                alert.show();
            }
        });

        saveInfo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //Toast.makeText(MainActivity.this, "click", Toast.LENGTH_LONG).show();

                AlertDialog.Builder alert_confirm2 = new AlertDialog.Builder(MainActivity.this);
                alert_confirm2.setMessage("데이터를 저장하시겠습니까?").setCancelable(false).setPositiveButton("확인",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                try {
                                    //String name = String.valueOf(textName.getText());
                                    int grade;
                                    String g = String.valueOf(textGrade.getText());
                                    if(!g.isEmpty()) grade= Integer.valueOf(g);
                                    else grade=1;
                                    if(grade<1 || grade>4){
                                        Toast.makeText(MainActivity.this, "학년을 다시 입력해 주세요", Toast.LENGTH_LONG).show();
                                        return ;
                                    }

                                    float score;
                                    String s = String.valueOf(textScore.getText());
                                    if(!s.isEmpty()) score= Float.valueOf(s);
                                    else score=0;
                                    if(score <0 || score >4.5){
                                        Toast.makeText(MainActivity.this, "학점을 다시 입력해 주세요.", Toast.LENGTH_LONG).show();
                                        return ;
                                    }

                                    int points;
                                    String p = String.valueOf(textPoints.getText());
                                    if(!p.isEmpty()) points= Integer.valueOf(p);
                                    else points=0;
                                    if(points<0){
                                        Toast.makeText(MainActivity.this, "어학점수를 다시 입력해 주세요", Toast.LENGTH_LONG).show();
                                        return ;
                                    }
                                    update(grade, score, points);

                                    select(); //update check
                                    Toast.makeText(MainActivity.this, "저장되었습니다.", Toast.LENGTH_LONG).show();
                                } catch (Exception e) {

                                }
                            }
                        }).setNegativeButton("취소",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(MainActivity.this, "취소되었습니다.", Toast.LENGTH_LONG).show();
                                return;
                            }
                        });
                AlertDialog alert2 = alert_confirm2.create();
                alert2.show();

            }
        });

        s.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                //Score.setText("position :" + position + getParent());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && mWebView.canGoBack()) {
            mWebView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    //db function
    public void insert(){
        db = helper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", "");
        values.put("grade", 0);
        values.put("score", 0);
        values.put("points", 0);
        values.put("checks", "00000");
        //values.put("age", age);
        //values.put("address", address);
        db.insert("WYW", null, values);
        Log.i("db", "[SQLite inset]");
    }

    public void update(int grade,float score,int points){
        //아무것도 입력안하고 check하면..?
        db = helper.getWritableDatabase();
        Cursor c = db.query("WYW", null, null, null, null, null, null);

        int count = 0;
        while(c.moveToNext()){
            count++;
        }
        //없을 시 생성!
        if( count==0 ){
            insert();
        }

        //db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("grade",grade);
        values.put("score", score);
        values.put("points", points);
        db.update("WYW", values, "_id=?", new String[]{"1"});
        Log.i("db", "[SQLite update] grade:" + grade + ", score:" + score + ", points:" + points);
    }
    public  void update(String check){
        //아무것도 입력안하고 check하면..?
        db = helper.getWritableDatabase();
        Cursor c = db.query("WYW", null, null, null, null, null, null);

        int count = 0;
        while(c.moveToNext()){
            count++;
        }
        //없을 시 생성!
        if( count==0 ){
            insert();
        }

        db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("checks", check);
        db.update("WYW", values, "_id=?", new String[]{"1"});
        Log.i("db", "[SQLite update] check:" + check);

//장학금(checkScholar), 취업(checkRecruit), 휴강(checkCancle), 수업자료(checkMaterials), 해외(checkForeign)
        urlsource = url + "?job=" + check.charAt(1)+"&scholar="+check.charAt(0)+"&Cancle="+check.charAt(2)+"&Materials="+check.charAt(3)+"Foreign="+check.charAt(4);
        mWebView.loadUrl(urlsource);

    }

    public void delete(String name){
        db = helper.getWritableDatabase();
        db.delete("WYW", "name=?", new String[]{name});
        Log.i("db", "[SQLite delete] " + name + "의 Data가 정상적으로 삭제 되었습니다.");
    }

    public void select(){
        db = helper.getWritableDatabase();
        Cursor c = db.query("WYW", null, null, null, null, null, null);
        while(c.moveToNext()){
            int _id = c.getInt(c.getColumnIndex("_id"));
            String name = c.getString(c.getColumnIndex("name"));
            int grade = c.getInt(c.getColumnIndex("grade"));
            float score = c.getFloat(c.getColumnIndex("score"));
            int points = c.getInt(c.getColumnIndex("points")); //차후 수정!!-------------------------
            String check = c.getString(c.getColumnIndex("checks"));
            Log.i("db", "[SQLite select] id:"+_id+" name:"+name+", checks:"+check+", grade:" + grade + ", score:" +score + ", points:"+points );
        }
    }

    //db helper class
    public class DBHelper extends SQLiteOpenHelper {
        public DBHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        public void onCreate(SQLiteDatabase db) {
            String sql = "create table if not exists WYW("
                    + "_id integer primary key autoincrement, "
                    + "name text, "
                    + "grade integer, "
                    + "score float, "
                    + "points integer, " //차후 수정!!!!----------------------------------------------
                    + "checks text);";
            db.execSQL(sql);
        }
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            String sql = "drop table if exists WYW";
            db.execSQL(sql);

            onCreate(db);
        }
    }

    //logout
    private void onClickLogout(){
        UserManagement.requestLogout(new LogoutResponseCallback() {
            @Override
            public void onCompleteLogout() {
                redirectLoginActivity();
            }
        });
    }
    protected void redirectLoginActivity() {       //세션 연결 성공 시 SignupActivity로 넘김
        final Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent);
        finish();
    }



}
