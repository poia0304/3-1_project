package com.example.tomato.wyw_6;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by leeheekyo on 2016-06-17.
 */
public class HttpAlarmActivity extends Activity {
    public DBHelper helper;
    public SQLiteDatabase db;

    HttpAlarmActivity(String result){
        Log.i("inAlarmActivity", result);

        helper = new DBHelper(HttpAlarmActivity.this, "person.db", null, 1);
        db = helper.getWritableDatabase();
        helper.onCreate(db);

    }
    /*
        helper = new DBHelper(MainActivity.this, "person.db", null, 1);
        db = helper.getWritableDatabase();
        helper.onCreate(db);

        Cursor ret = db.rawQuery("select * from WYW where _id=" + 1 +";",null);

        if(ret.moveToFirst()){

            Log.i("success","in if");

//url + "?job=" + check.charAt(1)+"&scholar="+check.charAt(0)+"&foreign="+check.charAt(2);

            String check = ret.getString(ret.getColumnIndex("checks"));
            int ij= ret.getInt(ret.getColumnIndex("job"));;
            int is = ret.getInt(ret.getColumnIndex("scholar"));
            int io = ret.getInt(ret.getColumnIndex("foreig"));
            int ij2 = 0;
            int is2 = 0;
            int io2 = 0;
            String ijt = "";
            String ist = "";
            String iot = "";

            JSONObject jonParser = new JSONObject(result);
            JSONArray jsonArray = jonParser.optJSONArray("data");

            for(int i=0; i < jsonArray.length(); i++){
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                String tmp = String.valueOf(jsonObject.optString("kind").toString());
                String ti =String.valueOf(jsonObject.optString("title").toString());
                Log.i("tmp is :", tmp);
                if(tmp.equals("job")){
                    ij2+=1;
                    ijt=ti;
                }
                else if(tmp.equals("scholar")){
                    is2+=1;
                    ist=ti;
                }
                else if(tmp.equals("foreign")){
                    io2+=1;
                    iot=ti;
                }

            }

            if(check.charAt(0)=='1'){
                //job
                update("job",ij2);
                if(ij != ij2){
                    //alarm
                    Log.i("change","job is : " +String.valueOf(ij2));
                    //Toast.makeText(HttpConnectionThread.this, "alarm", Toast.LENGTH_SHORT).show();
                }
            }
            else if(check.charAt(1)=='1'){
                //scholar
                update("scholar",is2);
                if(is!=is2){
                    Log.i("change","scholar is : "+String.valueOf(is2));
                }
            }
            else if(check.charAt(2)=='1'){
                //foreign
                update("foreig",io2);
                if(io!=io2){
                    Log.i("change","foreign is : "+String.valueOf(io2));
                }
            }
            //if(name.isEmpty()) {

            //}
            //Toast.makeText(MainActivity.this, urlsource, Toast.LENGTH_LONG).show();
        }
        else{
            //Toast.makeText(MainActivity.this, "no checks!", Toast.LENGTH_LONG).show();

        }
     */

    //db function
    public void insert(){
        db = helper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", "");
        values.put("checks", "000");
        values.put("job", 0);
        values.put("scholar", 0);
        values.put("foreig", 0);
        db.insert("WYW", null, values);
        Log.i("db", "[SQLite inset]");
    }

    public void update(String sig, int val){
        //아무것도 입력안하고 check하면..?
        db = helper.getWritableDatabase();
        Cursor c = db.query("WYW", null, null, null, null, null, null);

        int count = 0;
        while(c.moveToNext()){
            count++;
        }
        //없을 시 생성!
        if( count==0 ){
            insert();
        }

        //db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        if(sig.equals("job"))
            values.put("job", val);
        else if(sig.equals("scholar"))
            values.put("scholar",val);
        else if(sig.equals("foreig"))
            values.put("foreig", val);
        db.update("WYW", values, "_id=?", new String[]{"1"});
        Log.i("db", "[SQLite update] " + sig + " : " + val);
    }
    public void clear_db(){
        db = helper.getWritableDatabase();
        Cursor c = db.query("WYW", null, null, null, null, null, null);
        db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", "");
        db.update("WYW", values, "_id=?", new String[]{"1"});

    }

    public void delete(String name){
        db = helper.getWritableDatabase();
        db.delete("WYW", "name=?", new String[]{name});
        Log.i("db", "[SQLite delete] " + name + "의 Data가 정상적으로 삭제 되었습니다.");
    }

    public void select(){
        db = helper.getWritableDatabase();
        Cursor c = db.query("WYW", null, null, null, null, null, null);
        while(c.moveToNext()){
            int _id = c.getInt(c.getColumnIndex("_id"));
            String name = c.getString(c.getColumnIndex("name"));
            int job = c.getInt(c.getColumnIndex("job"));
            int scholar = c.getInt(c.getColumnIndex("scholar"));
            int foreign = c.getInt(c.getColumnIndex("foreig")); //차후 수정!!-------------------------
            String check = c.getString(c.getColumnIndex("checks"));
            Log.i("db", "[SQLite select] id:" + _id + " name:" + name + ", checks:" + check + "job:" + job + ", scholar:" + scholar + ", foreign:" + foreign);
        }
    }

    //db helper class
    public class DBHelper extends SQLiteOpenHelper {
        public DBHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        public void onCreate(SQLiteDatabase db) {
            String sql = "create table if not exists WYW("
                    + "_id integer primary key autoincrement, "
                    + "name text, "
                    + "job integer, "
                    + "scholar integer, "
                    + "foreig integer, "
                    + "checks text);";
            db.execSQL(sql);
        }
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            String sql = "drop table if exists WYW";
            db.execSQL(sql);

            onCreate(db);
        }
    }

}
