package com.example.tomato.wyw_6;

/**
 * Created by tomato on 2016-05-22.
 */
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.content.res.ResourcesCompat;
import android.text.Layout;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import com.kakao.network.ErrorResult;
import com.kakao.usermgmt.UserManagement;
import com.kakao.usermgmt.callback.LogoutResponseCallback;
import com.kakao.usermgmt.response.model.UserProfile;
import com.kakao.util.helper.log.Logger;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    public DBHelper helper;
    public SQLiteDatabase db;

    private WebView mWebView;
    private Button saveCheck;
    private Button saveInfo;
    private Button logOut;
    //private TextView Score;
    private CheckBox checkScholar;
    private CheckBox checkRecruit;
    private CheckBox checkForeign;
    private EditText textPNUid;
    private EditText textPNUpw;
    //private EditText textPoints;
    //private Spinner spinner;
    private AlarmManager am;

    String urlsource ;

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //toiec score
        //Spinner s = (Spinner)findViewById(R.id.spinner);

        //webview
        mWebView = (WebView)findViewById(R.id.webview);
        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);

        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                //String urlString = mWebView.getUrl().toString();
                //url_String.setText(urlString);
            }
        });

        checkScholar = (CheckBox)findViewById(R.id.checkScholar);
        checkRecruit = (CheckBox)findViewById(R.id.checkRecruit);
        checkForeign = (CheckBox)findViewById(R.id.checkForeign);
        saveCheck = (Button)findViewById(R.id.saveCheck);

        //textName = (EditText)findViewById(R.id.textName);
        textPNUid = (EditText)findViewById(R.id.textPNUid);
        textPNUpw = (EditText)findViewById(R.id.textPNUpw);
        //textPoints = (EditText)findViewById(R.id.textPoints);
        //spinner = (Spinner)findViewById(R.id.spinner);
        saveInfo = (Button)findViewById(R.id.saveInfo);
        logOut = (Button)findViewById(R.id.logout);

        helper = new DBHelper(MainActivity.this, "person.db", null, 1);
        db = helper.getWritableDatabase();
        helper.onCreate(db);

        Cursor result = db.rawQuery("select * from WYW where _id=" + 1 +";",null);
        if(result.moveToFirst()){
            String check = result.getString(result.getColumnIndex("checks"));
            String name = result.getString(result.getColumnIndex("name"));
            if(name.isEmpty()) {
                logOut.setVisibility(View.INVISIBLE);
                RelativeLayout r = (RelativeLayout) findViewById(R.id.tab3);
                r.setVisibility(View.INVISIBLE);
            }
            urlsource="http://keeper.cse.pusan.ac.kr/WYW_search.html" + "?job=" + check.charAt(1)+"&scholar="+check.charAt(0)+"&foreign="+check.charAt(2);
            //Toast.makeText(MainActivity.this, urlsource, Toast.LENGTH_LONG).show();
        }
        else{
            //Toast.makeText(MainActivity.this, "no checks!", Toast.LENGTH_LONG).show();
            urlsource="http://keeper.cse.pusan.ac.kr/WYW_search.html";
        }
        mWebView.loadUrl(urlsource);


        TabHost host = (TabHost)findViewById(R.id.tabHost);
        host.setup();

        //Tab 1
        TabHost.TabSpec spec = host.newTabSpec("Tab One");
        spec.setContent(R.id.tab1);
        spec.setIndicator("", ResourcesCompat.getDrawable(getResources(), R.drawable.check, null));
        host.addTab(spec);

        //Tab 2
        spec = host.newTabSpec("Tab Two");
        spec.setContent(R.id.tab2);
        spec.setIndicator("", ResourcesCompat.getDrawable(getResources(), R.drawable.search, null));
        host.addTab(spec);

        //Tab 3
        spec = host.newTabSpec("Tab Three");
        spec.setContent(R.id.tab3);
        spec.setIndicator("", ResourcesCompat.getDrawable(getResources(), R.drawable.info, null));
        host.addTab(spec);

        /*
        am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(MainActivity.this, AlarmReciver.class);
        PendingIntent sender = PendingIntent.getBroadcast(MainActivity.this, 0, intent, 0);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.add(Calendar.SECOND, 3);
        am.set(AlarmManager.RTC, calendar.getTimeInMillis(), sender);
        */

        //Toast.makeText(MainActivity.this, "start", Toast.LENGTH_LONG).show();
        //Log.i("db", "start~~~~~~~~~~~~ ");

        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clear_db();
                onClickLogout();

            }
        });

        saveCheck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                AlertDialog.Builder alert_confirm = new AlertDialog.Builder(MainActivity.this);
                alert_confirm.setMessage("정보를 저장하시겠습니까?").setCancelable(false).setPositiveButton("확인",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //고유 아이디!
                                String checkcheck = "";
//장학금(checkScholar), 취업(checkRecruit), 휴강(checkCancle), 수업자료(checkMaterials), 해외(checkForeign)
                                if (checkScholar.isChecked()) checkcheck += "1";
                                else checkcheck += "0";
                                if (checkRecruit.isChecked()) checkcheck += "1";
                                else checkcheck += "0";
                                if (checkForeign.isChecked()) checkcheck += "1";
                                else checkcheck += "0";

                                update(checkcheck);

                                select(); //update check!
                                Toast.makeText(MainActivity.this, "저장되었습니다.", Toast.LENGTH_LONG).show();
                                //web알림 http://keeper.cse.pusan.ac.kr/WYW_search.html

                                //test
                                if (checkcheck.equals("000")) {
                                    am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                                    Intent intent = new Intent(MainActivity.this, AlarmReciver.class);
                                    PendingIntent sender = PendingIntent.getBroadcast(MainActivity.this, 0, intent, 0);
                                    am.cancel(sender);

                                } else {
                                    am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                                    Intent intent = new Intent(MainActivity.this, AlarmReciver.class);
                                    PendingIntent sender = PendingIntent.getBroadcast(MainActivity.this, 0, intent, 0);
                                    am.setRepeating(AlarmManager.ELAPSED_REALTIME, 3000, 3000, sender);

                                }

                            }
                        }).setNegativeButton("취소",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // 'No'
                                Toast.makeText(MainActivity.this, "취소되었습니다.", Toast.LENGTH_LONG).show();

                                return;

                            }
                        });
                AlertDialog alert = alert_confirm.create();
                alert.show();
            }
        });

        saveInfo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //Toast.makeText(MainActivity.this, "click", Toast.LENGTH_LONG).show();

                AlertDialog.Builder alert_confirm2 = new AlertDialog.Builder(MainActivity.this);
                alert_confirm2.setMessage("PNU사이트와 연동하시겠습니까?").setCancelable(false).setPositiveButton("확인",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                try {
                                    String i = String.valueOf(textPNUid.getText());
                                    String p = String.valueOf(textPNUpw.getText());
                                    if (Integer.valueOf(i) < 0 || i.length() != 9) {
                                        Toast.makeText(MainActivity.this, "학번을 다시 입력해 주세요", Toast.LENGTH_LONG).show();
                                        return;
                                    }

                                    //서버에 정보를 보내는 부분...
                                    //mWebView.loadUrl("http://keeper.cse.pusan.ac.kr/tt.php?id="+i+"&pw="+p);

                                    //HttpConnectionThread httpConnectionThread = new HttpConnectionThread();
                                    //httpConnectionThread.execute("http://keeper.cse.pusan.ac.kr/tt.php?id=" + i + "&pw=" + p);

                                    textPNUid.setText("");
                                    textPNUpw.setText("");

                                    //web connect

                                    //before code!!!
                                    //String name = String.valueOf(textName.getText());
                                    //int grade;
                                    //spinner = (Spinner)findViewById(R.id.spinner);
                                    //if(!g.isEmpty()) grade= Integer.valueOf(g);
                                    //else grade=1;
                                    //if(grade<1 || grade>4){
                                    //    Toast.makeText(MainActivity.this, "학년을 다시 입력해 주세요", Toast.LENGTH_LONG).show();
                                    //    return ;
                                    //}
                                } catch (Exception e) {

                                }
                            }
                        }).setNegativeButton("취소",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(MainActivity.this, "취소되었습니다.", Toast.LENGTH_LONG).show();
                                return;
                            }
                        });
                AlertDialog alert2 = alert_confirm2.create();
                alert2.show();

            }
        });

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && mWebView.canGoBack()) {
            mWebView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    //db function
    public void insert(){
        db = helper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", "");
        values.put("checks", "000");
        values.put("job", "");
        values.put("scholar", "");
        values.put("foreig", "");
        db.insert("WYW", null, values);
        Log.i("db", "[SQLite inset]");
    }

    public void update(String sig, String val){
        //아무것도 입력안하고 check하면..?
        db = helper.getWritableDatabase();
        Cursor c = db.query("WYW", null, null, null, null, null, null);

        int count = 0;
        while(c.moveToNext()){
            count++;
        }
        //없을 시 생성!
        if( count==0 ){
            insert();
        }

        //db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        if(sig.equals("job"))
            values.put("job", val);
        else if(sig.equals("scholar"))
            values.put("scholar",val);
        else if(sig.equals("foreig"))
            values.put("foreig", val);
        db.update("WYW", values, "_id=?", new String[]{"1"});
        Log.i("db", "[SQLite update] " + sig + " : " + val);
    }
    public void clear_db(){
        db = helper.getWritableDatabase();
        Cursor c = db.query("WYW", null, null, null, null, null, null);
        db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", "");
        db.update("WYW", values, "_id=?", new String[]{"1"});

    }
    public  void update(String check){
        //아무것도 입력안하고 check하면..?
        db = helper.getWritableDatabase();
        Cursor c = db.query("WYW", null, null, null, null, null, null);

        int count = 0;
        while(c.moveToNext()){
            count++;
        }
        //없을 시 생성!
        if( count==0 ){
            insert();
        }

        db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("checks", check);
        db.update("WYW", values, "_id=?", new String[]{"1"});
        Log.i("db", "[SQLite update] check:" + check);
//장학금(checkScholar), 취업(checkRecruit), 휴강(checkCancle), 수업자료(checkMaterials), 해외(checkForeign)
        urlsource = "http://keeper.cse.pusan.ac.kr/WYW_search.html" + "?job=" + check.charAt(1)+"&scholar="+check.charAt(0)+"&foreign="+check.charAt(2);
        mWebView.loadUrl(urlsource);

    }

    public void delete(String name){
        db = helper.getWritableDatabase();
        db.delete("WYW", "name=?", new String[]{name});
        Log.i("db", "[SQLite delete] " + name + "의 Data가 정상적으로 삭제 되었습니다.");
    }

    public void select(){
        db = helper.getWritableDatabase();
        Cursor c = db.query("WYW", null, null, null, null, null, null);
        while(c.moveToNext()){
            int _id = c.getInt(c.getColumnIndex("_id"));
            String name = c.getString(c.getColumnIndex("name"));
            String job = c.getString(c.getColumnIndex("job"));
            String scholar = c.getString(c.getColumnIndex("scholar"));
            String foreign = c.getString(c.getColumnIndex("foreig")); //차후 수정!!-------------------------
            //int foreign = c.getInt(c.getColumnIndex("foreig")); //차후 수정!!-------------------------
            String check = c.getString(c.getColumnIndex("checks"));
            Log.i("db", "[SQLite select] id:"+_id+" name:"+name+", checks:"+check + "job:" + job+ ", scholar:" +scholar+ ", foreign:"+foreign);
        }
    }

    //db helper class
    public class DBHelper extends SQLiteOpenHelper {
        public DBHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        public void onCreate(SQLiteDatabase db) {
            String sql = "create table if not exists WYW("
                    + "_id integer primary key autoincrement, "
                    + "name text, "
                    + "job text, "
                    + "scholar text, "
                    + "foreig text, "
                    + "checks text);";
            db.execSQL(sql);
        }
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            String sql = "drop table if exists WYW";
            db.execSQL(sql);

            onCreate(db);
        }
    }

    //logout
    private void onClickLogout(){
        UserManagement.requestLogout(new LogoutResponseCallback() {
            @Override
            public void onCompleteLogout() {
                redirectLoginActivity();
            }
        });
    }
    protected void redirectLoginActivity() {       //세션 연결 성공 시 SignupActivity로 넘김
        final Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent);
        finish();
    }

/*
        helper = new DBHelper(MainActivity.this, "person.db", null, 1);
        db = helper.getWritableDatabase();
        helper.onCreate(db);

        Cursor ret = db.rawQuery("select * from WYW where _id=" + 1 +";",null);

        if(ret.moveToFirst()){

            Log.i("success","in if");

//url + "?job=" + check.charAt(1)+"&scholar="+check.charAt(0)+"&foreign="+check.charAt(2);

            String check = ret.getString(ret.getColumnIndex("checks"));
            int ij= ret.getInt(ret.getColumnIndex("job"));;
            int is = ret.getInt(ret.getColumnIndex("scholar"));
            int io = ret.getInt(ret.getColumnIndex("foreig"));
            int ij2 = 0;
            int is2 = 0;
            int io2 = 0;
            String ijt = "";
            String ist = "";
            String iot = "";

            JSONObject jonParser = new JSONObject(result);
            JSONArray jsonArray = jonParser.optJSONArray("data");

            for(int i=0; i < jsonArray.length(); i++){
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                String tmp = String.valueOf(jsonObject.optString("kind").toString());
                String ti =String.valueOf(jsonObject.optString("title").toString());
                Log.i("tmp is :", tmp);
                if(tmp.equals("job")){
                    ij2+=1;
                    ijt=ti;
                }
                else if(tmp.equals("scholar")){
                    is2+=1;
                    ist=ti;
                }
                else if(tmp.equals("foreign")){
                    io2+=1;
                    iot=ti;
                }

            }

            if(check.charAt(0)=='1'){
                //job
                update("job",ij2);
                if(ij != ij2){
                    //alarm
                    Log.i("change","job is : " +String.valueOf(ij2));
                    //Toast.makeText(HttpConnectionThread.this, "alarm", Toast.LENGTH_SHORT).show();
                }
            }
            else if(check.charAt(1)=='1'){
                //scholar
                update("scholar",is2);
                if(is!=is2){
                    Log.i("change","scholar is : "+String.valueOf(is2));
                }
            }
            else if(check.charAt(2)=='1'){
                //foreign
                update("foreig",io2);
                if(io!=io2){
                    Log.i("change","foreign is : "+String.valueOf(io2));
                }
            }
            //if(name.isEmpty()) {

            //}
            //Toast.makeText(MainActivity.this, urlsource, Toast.LENGTH_LONG).show();
        }
        else{
            //Toast.makeText(MainActivity.this, "no checks!", Toast.LENGTH_LONG).show();

        }
*/

}
