package com.example.tomato.wyw_6;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import java.util.logging.Handler;

/**
 * Created by leeheekyo on 2016-06-04.
 */
public class AlarmReciver extends BroadcastReceiver {


    public void onReceive(Context context, Intent intent){
        //Log.i("db", "start AlarmReciver!!!!!!!!~~~~~ ");
        Toast.makeText(context, "alarm", Toast.LENGTH_SHORT).show();
        HttpConnectionThread httpConnectionThread = new HttpConnectionThread(context);
        httpConnectionThread.execute("http://keeper.cse.pusan.ac.kr/data.json").toString();
    }

}
