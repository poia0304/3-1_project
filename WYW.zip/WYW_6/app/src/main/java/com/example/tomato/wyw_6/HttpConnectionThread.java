package com.example.tomato.wyw_6;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by leeheekyo on 2016-06-08.
 */
public class HttpConnectionThread extends AsyncTask<String, Void, String> {
    DBHelper helper; //파싱해서 알람!!
    SQLiteDatabase db;
    @Override
    protected String doInBackground(String... url) {

        URL urli;
        String response = null;
        String result="";
//        geturl=m.Geturl();

        try {
            urli = new URL(url[0]);
            HttpURLConnection conn = (HttpURLConnection) urli.openConnection();
            conn.setReadTimeout(10000 /* milliseconds */);
            conn.setConnectTimeout(15000 /* milliseconds */);
            conn.setRequestMethod("POST");
            conn.setDoInput(true);

            conn.connect();

            response = conn.getResponseMessage();
            Log.d("RESPONSE", "The response is: " + response);
            InputStream in = new BufferedInputStream(conn.getInputStream());

            BufferedReader reader = new BufferedReader(new InputStreamReader(in));

            String line;
            Log.i("start", result);
            while ((line = reader.readLine()) != null) {
                result+=line;
                Log.i("ok", result);
                //text1.setText(result);
                //Toast.makeText(context, "is it?", Toast.LENGTH_SHORT).show();
            }
            Log.i("RESPONSE", "The result is: " +  result);

            //db조회 및 data 파싱

            Cursor ret = db.rawQuery("select * from WYW where _id=" + 1 +";",null);
            if(ret.moveToFirst()){
//url + "?job=" + check.charAt(1)+"&scholar="+check.charAt(0)+"&foreign="+check.charAt(2);

                String check = ret.getString(ret.getColumnIndex("checks"));
                //int name = ret.getString(ret.getColumnIndex("job"));
                //if(name.isEmpty()) {

                //}
                //Toast.makeText(MainActivity.this, urlsource, Toast.LENGTH_LONG).show();
            }
            else{
                //Toast.makeText(MainActivity.this, "no checks!", Toast.LENGTH_LONG).show();

            }


        }
        catch (IOException e) {

        }

        return response;
    }

    @Override
    protected void onPostExecute(String result) {
        // UI 업데이트가 구현될 부분
        //Log.i("ok", result);
    }

    //db function
    public void insert(){
        db = helper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", "");
        values.put("checks", "000");
        values.put("job", 0);
        values.put("scholar", 0);
        values.put("foreign", 0);
        db.insert("WYW", null, values);
        Log.i("db", "[SQLite inset]");
    }

    public void delete(String name){
        db = helper.getWritableDatabase();
        db.delete("WYW", "name=?", new String[]{name});
        Log.i("db", "[SQLite delete] " + name + "의 Data가 정상적으로 삭제 되었습니다.");
    }

    public void select(){
        db = helper.getWritableDatabase();
        Cursor c = db.query("WYW", null, null, null, null, null, null);
        while(c.moveToNext()){
            int _id = c.getInt(c.getColumnIndex("_id"));
            String name = c.getString(c.getColumnIndex("name"));
            int job = c.getInt(c.getColumnIndex("job"));
            int scholar = c.getInt(c.getColumnIndex("scholar"));
            int foreign = c.getInt(c.getColumnIndex("foreign")); //차후 수정!!-------------------------
            String check = c.getString(c.getColumnIndex("checks"));
            Log.i("db", "[SQLite select] id:"+_id+" name:"+name+", checks:"+check + "job:" + job+ ", scholar:" +scholar+ ", foreign:"+foreign);
        }
    }

    //db helper class
    public class DBHelper extends SQLiteOpenHelper {
        public DBHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        public void onCreate(SQLiteDatabase db) {
            String sql = "create table if not exists WYW("
                    + "_id integer primary key autoincrement, "
                    + "name text, "
                    + "job integer, "
                    + "scholar float, "
                    + "foreign integer, "
                    + "checks text);";
            db.execSQL(sql);
        }
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            String sql = "drop table if exists WYW";
            db.execSQL(sql);

            onCreate(db);
        }
    }


}