package com.example.tomato.wyw_6;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by leeheekyo on 2016-06-08.
 */

public class HttpConnectionThread extends AsyncTask<String, Void, String> {
    public DBHelper helper;
    public SQLiteDatabase db;
    private Context context;

    HttpConnectionThread(Context c){
        context = c;
    }

    @Override
    protected String doInBackground(String... url) {

        URL urli;
        String response = null;
        String result="";
//        geturl=m.Geturl();

        try {
            urli = new URL(url[0]);
            HttpURLConnection conn = (HttpURLConnection) urli.openConnection();
            conn.setReadTimeout(10000 /* milliseconds */);
            conn.setConnectTimeout(15000 /* milliseconds */);
            conn.setRequestMethod("POST");
            conn.setDoInput(true);

            conn.connect();

            response = conn.getResponseMessage();
            //Log.d("RESPONSE", "The response is: " + response);
            InputStream in = new BufferedInputStream(conn.getInputStream());

            BufferedReader reader = new BufferedReader(new InputStreamReader(in));

            String line;
            //Log.i("start", result);
            while ((line = reader.readLine()) != null) {
                result+=line;
            }
            //xml parsing 한 거

            //Log.i("RESPONSE", "The result is: " + result);

 //           HttpAlarmActivity alarmactivity = new HttpAlarmActivity(result);

            //db조회 및 data 파싱


        }
        catch (Exception e) {

        }

        return result;
    }

    protected void onPostExecute(String result) {  //getApplicationContext()
        //xml들고 온 뒤 실행하는 프로그램()
        /*
        Log.i("first result", result);
        result = result.replace('\'', '$');
        result=result.replace('\"','\'');
        result=result.replace('$','\"');
        Log.i("result second", result);
        helper = new DBHelper(context, "person.db", null, 1);
        db = helper.getWritableDatabase();
        helper.onCreate(db);

        Cursor ret = db.rawQuery("select * from WYW where _id=" + 1 +";",null);

        if(ret.moveToFirst()){

//url + "?job=" + check.charAt(1)+"&scholar="+check.charAt(0)+"&foreign="+check.charAt(2);

            String form ="";
            for(int i=7; i<result.length(); i++) form+=result.charAt(i);
            form = form.trim();
            //result.substring(9,result.length());
            Log.i("form", form);
 //String str = '{"data":[{"date": "2016-05-26", "from": "cse", "kind": "scholar", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=470566&pages=30", "title": "[장학]2016학년도 KT 창의혁신리더 미래창조인재 부문 장학생 선발(수정):~5.31(정오까지)"}, {"date": "2016-05-25", "from": "cse", "kind": "scholar", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=470504&pages=30", "title": "2016년 이공계 우수학생 국가장학사업 환수제도 권역별 설명회 참석 안내"}, {"date": "2016-05-23", "from": "cse", "kind": "scholar", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=470001&pages=30", "title": "[장학] 2016학년도 2학기 국가근로장학금 학생 신청기간 안내"}, {"date": "2016-05-23", "from": "cse", "kind": "scholar", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=470126&pages=30", "title": "[면담]2016.1학기 지도교수 면담 재공지:~5.31"}, {"date": "2016-05-23", "from": "foreign", "kind": "foreign", "link": "http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=470009", "title": "[해외파견] 2016. 2학기 해외파견 합격자 PNU WILL Program 신청"}, {"date": "2016-05-20", "from": "cse", "kind": "foreign", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=469902&pages=30", "title": "IITP 해외교육프로그램(퍼듀대) 프로그램 학생 참여 안내"}, {"date": "2016-05-20", "from": "cse", "kind": "job", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=469861&pages=30", "title": "[학과활동인정]미국 UMKC 최백영 교수 세미나:6.10(금)14:00"}, {"date": "2016-05-20", "from": "cse", "kind": "foreign", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=469861&pages=30", "title": "[학과활동인정]미국 UMKC 최백영 교수 세미나:6.10(금)14:00"}, {"date": "2016-05-18", "from": "cse", "kind": "job", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=469688&pages=30", "title": "2016 하계 유학생 인턴십 프로그램 참가자 모집 안내"}, {"date": "2016-05-18", "from": "cse", "kind": "foreign", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=469688&pages=30", "title": "2016 하계 유학생 인턴십 프로그램 참가자 모집 안내"}, {"date": "2016-05-18", "from": "foreign", "kind": "foreign", "link": "http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=469682", "title": "[2016-2학기] 기초학문진흥사업 해외파견 합격자 및 OT알림 "}, {"date": "2016-05-17", "from": "cse", "kind": "scholar", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=469513&pages=30", "title": "[장학] 2016년 2학기 국가장학금 1차 신청 안내"}, {"date": "2016-05-17", "from": "cse", "kind": "scholar", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=469520&pages=30", "title": "2016-2017년도 쿠웨이트 정부초청 아랍어 어학연수 장학생 모집"}, {"date": "2016-05-16", "from": "foreign", "kind": "foreign", "link": "http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=469460", "title": "[합격자 필독] 2016. 2학기 해외파견 합격자 PNU WILL Program 신청 안내"}, {"date": "2016-05-16", "from": "foreign", "kind": "foreign", "link": "http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=469457", "title": "[설명회] 2016 상반기 해외파견 프로그램 정기 설명회 및 귀국보고회 자료"}, {"date": "2016-05-13", "from": "cse", "kind": "foreign", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=469216&pages=30", "title": " 2016학년도 하계 계절학기·어학연수 자비유학 프로그램”참가자 모집 안내"}, {"date": "2016-05-13", "from": "cse", "kind": "scholar", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=469215&pages=30", "title": "2017 일본 문부과학성 연구유학생 모집 안내"}, {"date": "2016-05-13", "from": "cse", "kind": "foreign", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=469215&pages=30", "title": "2017 일본 문부과학성 연구유학생 모집 안내"}, {"date": "2016-05-13", "from": "foreign", "kind": "scholar", "link": "http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=469227", "title": "스페인어 언어교육과정 모집 안내 "}, {"date": "2016-05-13", "from": "foreign", "kind": "scholar", "link": "http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=469289", "title": "쿠웨이트 정부초청 아랍어 어학연수 장학생 모집"}, {"date": "2016-05-13", "from": "foreign", "kind": "scholar", "link": "http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=469220", "title": "런던 로드메이어 맨션하우스 장학금 안내"}, {"date": "2016-05-12", "from": "cse", "kind": "job", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=468365&pages=30", "title": "미래인재개발원 저학년 진로탐색 프로그램 참가자 모집 "}, {"date": "2016-05-11", "from": "cse", "kind": "job", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=468245&pages=30", "title": "개교 70주년 기념 2016 PNU 대학생활 엑스포 개최"}, {"date": "2016-05-11", "from": "foreign", "kind": "foreign", "link": "http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=468234", "title": "[자비유학]2016학년도 하계 “ 계절학기 · 어학연수 파견 자비유학 프로그램 ”선발 안내"}, {"date": "2016-05-09", "from": "cse", "kind": "job", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=467995&pages=30", "title": "맞춤형 취업지원 프로그램 아이디어 공모 안내"}, {"date": "2016-05-09", "from": "foreign", "kind": "scholar", "link": "http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=467929", "title": "[주한일본대사관] 2017 일본 정부(문부과학성) 초청 연구장학생 선발 안내"}, {"date": "2016-05-09", "from": "foreign", "kind": "foreign", "link": "http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=468052", "title": "2016-2학기 기초학문진흥사업 해외파견 추가 모집 공고(토익 제출가능)"}, {"date": "2016-05-04", "from": "cse", "kind": "foreign", "link": "http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=467801&pages=30", "title": "학생 해외파견 프로그램 정기설명회 및 쌩체험담 행사 안내"}]}';
//
            try {
                String check = ret.getString(ret.getColumnIndex("checks"));
                String sj= ret.getString(ret.getColumnIndex("job"));;
                String ss = ret.getString(ret.getColumnIndex("scholar"));
                String sf = ret.getString(ret.getColumnIndex("foreig"));
                String ijt = "";
                String ist = "";
                String iot = "";

                //Toast.makeText(context, check+sj+ss+sf, Toast.LENGTH_LONG).show();

                JSONObject jonParser = null;
                String str="{'data':[{'date': '16-04-27', 'from': 'stat', 'kind': 'foreign', 'link': 'http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=4741&boardSeq=467094', 'title': '2016학년도 하계 해외도전과 체험 참가팀 모집'},{'date': '16-04-27', 'from': 'stat', 'kind': 'job', 'link': 'http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=4741&boardSeq=467094', 'title': '직업'}]}";

                jonParser = new JSONObject(str);
                JSONArray jsonArray = jonParser.optJSONArray("data");
                for(int i=0; i < jsonArray.length(); i++){
                    JSONObject jsonObject = jsonArray.getJSONObject(i);

                    String tmp = String.valueOf(jsonObject.optString("kind").toString());
                    String ti =String.valueOf(jsonObject.optString("title").toString());
                    Log.i("tmp, ti", tmp+", "+ti);

                    if(tmp.equals("job")){ //check.charAt[0]=='0'
                        Log.i("job :", tmp);
                        ijt=ti;
                    }
                    else if(tmp.equals("scholar")){
                        Log.i("scholar is :", tmp);
                        ist=ti;
                    }
                    else if(tmp.equals("foreign")){
                        Log.i("foreign is :", tmp);
                        iot=ti;
                    }

                }
                //if(name.isEmpty()) {

                //}
                //Toast.makeText(MainActivity.this, urlsource, Toast.LENGTH_LONG).show();
            } catch (JSONException e) {
                e.printStackTrace();
            }


        }
        else{
            //Toast.makeText(MainActivity.this, "no checks!", Toast.LENGTH_LONG).show();

        }*/
    }

    //db function
    public void insert(){
        db = helper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", "");
        values.put("checks", "000");
        values.put("job", "");
        values.put("scholar", "");
        values.put("foreig", "");
        db.insert("WYW", null, values);
        Log.i("db", "[SQLite inset]");
    }

    public void update(String sig, String val){
        //아무것도 입력안하고 check하면..?
        db = helper.getWritableDatabase();
        Cursor c = db.query("WYW", null, null, null, null, null, null);

        int count = 0;
        while(c.moveToNext()){
            count++;
        }
        //없을 시 생성!
        if( count==0 ){
            insert();
        }

        //db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        if(sig.equals("job"))
            values.put("job", val);
        else if(sig.equals("scholar"))
            values.put("scholar",val);
        else if(sig.equals("foreig"))
            values.put("foreig", val);
        db.update("WYW", values, "_id=?", new String[]{"1"});
        Log.i("db", "[SQLite update] " + sig + " : " + val);
    }
    public void clear_db(){
        db = helper.getWritableDatabase();
        Cursor c = db.query("WYW", null, null, null, null, null, null);
        db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", "");
        db.update("WYW", values, "_id=?", new String[]{"1"});

    }

    public void delete(String name){
        db = helper.getWritableDatabase();
        db.delete("WYW", "name=?", new String[]{name});
        Log.i("db", "[SQLite delete] " + name + "의 Data가 정상적으로 삭제 되었습니다.");
    }

    public void select(){
        db = helper.getWritableDatabase();
        Cursor c = db.query("WYW", null, null, null, null, null, null);
        while(c.moveToNext()){
            int _id = c.getInt(c.getColumnIndex("_id"));
            String name = c.getString(c.getColumnIndex("name"));
            String job = c.getString(c.getColumnIndex("job"));
            String scholar = c.getString(c.getColumnIndex("scholar"));
            String foreign = c.getString(c.getColumnIndex("foreig"));
            //int foreign = c.getInt(c.getColumnIndex("foreig")); //차후 수정!!-------------------------
            String check = c.getString(c.getColumnIndex("checks"));
            Log.i("db", "[SQLite select] id:" + _id + " name:" + name + ", checks:" + check + "job:" + job + ", scholar:" + scholar + ", foreign:" + foreign);
        }
    }

    //db helper class
    public class DBHelper extends SQLiteOpenHelper {
        public DBHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        public void onCreate(SQLiteDatabase db) {
            String sql = "create table if not exists WYW("
                    + "_id integer primary key autoincrement, "
                    + "name text, "
                    + "job text, "
                    + "scholar text, "
                    + "foreig text, "
                    + "checks text);";
            db.execSQL(sql);
        }
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            String sql = "drop table if exists WYW";
            db.execSQL(sql);

            onCreate(db);
        }
    }
}