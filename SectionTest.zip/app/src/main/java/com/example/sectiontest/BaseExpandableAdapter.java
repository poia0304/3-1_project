package com.example.sectiontest;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by 한결 on 2016-06-18.
 */

public class BaseExpandableAdapter extends BaseExpandableListAdapter {
    private ArrayList<String> groupList = null;
    private ArrayList<List<Map<String,?>>> childList = null;
    private LayoutInflater inflater = null;

    public BaseExpandableAdapter(Context c, ArrayList<String> groupList,
                                 ArrayList<List<Map<String,?>>> childList){
        super();
        this.inflater = LayoutInflater.from(c);
        this.groupList = groupList;
        this.childList = childList;
    }

    // 그룹 포지션을 반환한다.
    @Override
    public String getGroup(int groupPosition) {
        return groupList.get(groupPosition);
    }

    // 그룹 사이즈를 반환한다.
    @Override
    public int getGroupCount() {
        return groupList.size();
    }

    // 그룹 ID를 반환한다.
    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    // 그룹뷰 각각의 ROW
    @Override
    public View getGroupView(int groupPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {
        View v = convertView;
        v = inflater.inflate(R.layout.list_header, parent, false);
        TextView header = (TextView) v.findViewById(R.id.header);
        header.setText(getGroup(groupPosition));

        return v;
    }

    // 차일드뷰를 반환한다.
    @Override
    public String getChild(int groupPosition, int childPosition) {
        return childList.get(groupPosition).get(childPosition).get("title").toString();
    }

    public String getDate(int groupPosition, int childPosition) {
        return childList.get(groupPosition).get(childPosition).get("date").toString();
    }

    public String getFrom(int groupPosition, int childPosition) {
        return childList.get(groupPosition).get(childPosition).get("from").toString();
    }

    // 차일드뷰 사이즈를 반환한다.
    @Override
    public int getChildrenCount(int groupPosition) {
        return childList.get(groupPosition).size();
    }

    // 차일드뷰 ID를 반환한다.
    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    // 차일드뷰 각각의 ROW
    @Override
    public View getChildView(int groupPosition, int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {

        View v = convertView;
        v = inflater.inflate(R.layout.list_complex, null);

        TextView title = (TextView) v.findViewById(R.id.title);
        TextView date = (TextView) v.findViewById(R.id.date);
        ImageView image = (ImageView) v.findViewById(R.id.image);

        String tmp = getFrom(groupPosition,childPosition);
        if (tmp.equalsIgnoreCase("cse")) {
            image.setImageResource(R.drawable.cse_logo);
        }
        else if(tmp.equalsIgnoreCase("ie")) {
            image.setImageResource(R.drawable.ie_logo);
        }
        else if(tmp.equalsIgnoreCase("stat")) {
            image.setImageResource(R.drawable.stat_logo);
        }
        else if(tmp.equalsIgnoreCase("foreign")) {
            image.setImageResource(R.drawable.foreign_logo);
        }

        title.setText(getChild(groupPosition, childPosition));
        date.setText(getDate(groupPosition,childPosition));

        return v;
    }

    @Override
    public boolean hasStableIds() { return true; }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) { return true; }

}
