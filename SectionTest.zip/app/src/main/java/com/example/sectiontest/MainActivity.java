package com.example.sectiontest;

import android.content.Intent;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ExpandableListView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> mGroupList;

    private ArrayList<List<Map<String,?>>> mChildList ;

    private List<Map<String,?>> mChildListContentJob;
    private List<Map<String,?>> mChildListContentScholar ;
    private List<Map<String,?>> mChildListContentForeign ;

    private ExpandableListView mListView;

    public Map<String,?> createItem(String title, String date, String from,String url) {
        Map<String,String> item = new HashMap<String,String>();
        item.put("title", title);
        item.put("date", date);
        item.put("from",from);
        item.put("link",url);
        return item;
    }

    Comparator<Map<String,?>> comparator = new Comparator<Map<String,?>>(){
        @Override
        public int compare(Map<String,?> o1,Map<String,?> o2) {
            return o1.get("date").toString().compareTo(o2.get("date").toString());
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mListView = (ExpandableListView)findViewById(R.id.e_list);

        mGroupList = new ArrayList<String>();

        mChildList = new ArrayList<List<Map<String,?>>>();

        mChildListContentJob = new LinkedList<Map<String,?>>();
        mChildListContentScholar = new LinkedList<Map<String,?>>();
        mChildListContentForeign = new LinkedList<Map<String,?>>();

        mGroupList.add("취업");
        mGroupList.add("장학");
        mGroupList.add("해외");

        doJSONParser();
        Toast.makeText(MainActivity.this,mChildListContentJob.get(1).toString(),Toast.LENGTH_SHORT).show();
        Collections.sort(mChildListContentJob, comparator);
        Collections.sort(mChildListContentScholar,comparator);
        Collections.sort(mChildListContentForeign,comparator);
        Toast.makeText(MainActivity.this,mChildListContentJob.get(1).toString(),Toast.LENGTH_SHORT).show();

        mChildList.add(mChildListContentJob);
        mChildList.add(mChildListContentScholar);
        mChildList.add(mChildListContentForeign);

        mListView.setAdapter(new BaseExpandableAdapter(this, mGroupList, mChildList));

        mListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                String url = mChildList.get(groupPosition).get(childPosition).get("link").toString();
                Toast.makeText(MainActivity.this, url, Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(MainActivity.this, WebViewActivity.class);
                intent.putExtra("url", url);
                startActivity(intent);

                return false;
            }
        });







       /* mListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                Toast.makeText(getApplicationContext(), "g click = " + groupPosition, Toast.LENGTH_SHORT).show();
                return false;
            }
        });

        mListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
            @Override
            public void onGroupCollapse(int groupPosition) {
                Toast.makeText(getApplicationContext(), "g Collapse = " + groupPosition,
                        Toast.LENGTH_SHORT).show();
            }
        });

        mListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            @Override
            public void onGroupExpand(int groupPosition) {
                Toast.makeText(getApplicationContext(), "g Expand = " + groupPosition,
                        Toast.LENGTH_SHORT).show();
            }
        });*/
    }


    void doJSONParser() {
        String str = "[{\"title\":\"[장학]2016.1학기 학생과 미경유 교내.외 장학금 수혜현황 제출\",\"link\":\"http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=472356&pages=30\",\"date\":\"2016-06-15\",\"from\":\"cse\",\"kind\":\"scholar\"},{\"title\":\"[장학]2016.1학기 학생과 미경유 교내.외 장학금 수혜현황 제출\",\"link\":\"http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=472356&pages=30\",\"date\":\"2016-06-15\",\"from\":\"cse\",\"kind\":\"foreign\"},{\"title\":\"2016학년도 2학기 정규학기·어학연수 자비유학 프로그램 안내\",\"link\":\"http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=472420&pages=30\",\"date\":\"2016-06-15\",\"from\":\"cse\",\"kind\":\"foreign\"},{\"title\":\"하절기 해외여행시 감염병 주의사항 안내\",\"link\":\"http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=471868&pages=30\",\"date\":\"2016-06-09\",\"from\":\"cse\",\"kind\":\"foreign\"},{\"title\":\"[장학]2016학년도 2학기 발전기금(경헌장학금) 장학생(다문화가족) 추천:~6.14\",\"link\":\"http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=472008&pages=30\",\"date\":\"2016-06-10\",\"from\":\"cse\",\"kind\":\"scholar\"},{\"title\":\"2016학년도 2학기 한국장학재단 국가장학금 1차 신청 독려 : ~6.14(화) 18:00까지\",\"link\":\"http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=471946&pages=30\",\"date\":\"2016-06-10\",\"from\":\"cse\",\"kind\":\"scholar\"},{\"title\":\"2016.2학기 휴복학기간 안내\",\"link\":\"http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=471717&pages=30\",\"date\":\"2016-06-08\",\"from\":\"cse\",\"kind\":\"scholar\"},{\"title\":\"[수정게시:기한연장]PNU SW Premier Membership 모집 안내\",\"link\":\"http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=471675&pages=30\",\"date\":\"2016-06-07\",\"from\":\"cse\",\"kind\":\"job\"},{\"title\":\"[수정게시:기한연장]PNU SW Premier Membership 모집 안내\",\"link\":\"http://uwcms.pusan.ac.kr/trans/user/board_view.jsp?siteId=cse&boardId=10418&boardSeq=471675&pages=30\",\"date\":\"2016-06-07\",\"from\":\"cse\",\"kind\":\"foreign\"},{\"title\":\"2016. 1학기 PNU Buddy 활동보고서 제출 안내\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=473261\",\"date\":\"2016-06-17\",\"from\":\"foreign\",\"kind\":\"foreign\"},{\"title\":\"스웨덴 유학홍보 아이디어 UCC 공모전 안내\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=472437\",\"date\":\"2016-06-16\",\"from\":\"foreign\",\"kind\":\"foreign\"},{\"title\":\" 2016 제 3 차 기관토플 (TOEFL ITP) 시행안내\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=471968\",\"date\":\"2016-06-10\",\"from\":\"foreign\",\"kind\":\"foreign\"},{\"title\":\"[자비유학] 2016학년도 2학기 정규학기·어학연수 파견 자비유학 프로그램 선발안내\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=472341\",\"date\":\"2016-06-15\",\"from\":\"foreign\",\"kind\":\"foreign\"},{\"title\":\"[단기파견] 2016 동계 단기파견 프로그램(영어연수) 참가자 모집\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=472812\",\"date\":\"2016-06-16\",\"from\":\"foreign\",\"kind\":\"foreign\"},{\"title\":\"[단기파견] 2016 동계 단기파견 프로그램(일본어연수) 참가자 모집\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=472821\",\"date\":\"2016-06-16\",\"from\":\"foreign\",\"kind\":\"foreign\"},{\"title\":\"제9회 UN국제기구 진출 설명회 참가자 모집 \",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=472333\",\"date\":\"2016-06-15\",\"from\":\"foreign\",\"kind\":\"job\"},{\"title\":\"[주한미국대사관]7월8일(금)-9일(토) 경상지역 멘토링 프로그램 신청 안내\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=471760\",\"date\":\"2016-06-08\",\"from\":\"foreign\",\"kind\":\"job\"},{\"title\":\"[주한미국대사관]7월8일(금)-9일(토) 경상지역 멘토링 프로그램 신청 안내\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=471760\",\"date\":\"2016-06-08\",\"from\":\"foreign\",\"kind\":\"foreign\"},{\"title\":\"2016 PNU Summer School  버디 합격자 공고(수정)\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=470903\",\"date\":\"2016-05-30\",\"from\":\"foreign\",\"kind\":\"foreign\"},{\"title\":\"부산시민도서관 미국 유학 및 학생 비자 설명회 안내\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=471077\",\"date\":\"2016-06-01\",\"from\":\"foreign\",\"kind\":\"foreign\"},{\"title\":\"[2016학년도1학기]교환/교비/자비유학생 귀국안내 및 성적표 수령명단\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=471528\",\"date\":\"2016-06-07\",\"from\":\"foreign\",\"kind\":\"foreign\"},{\"title\":\"[단기파견] 2016 하계 하얼빈공업대학 위해캠퍼스 International Summer School 참가자 모집 \",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=10003&boardSeq=471406\",\"date\":\"2016-06-03\",\"from\":\"foreign\",\"kind\":\"foreign\"},{\"title\":\"대한민국 히든챔피언 기업과 함께하는 대학생 아이디어 경진대회 \",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=8927&boardSeq=473173\",\"date\":\"16-06-17\",\"from\":\"ie\",\"kind\":\"job\"},{\"title\":\"상생 빛 드림 장학생 추천(~6/7)\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=8927&boardSeq=471379\",\"date\":\"16-06-03\",\"from\":\"ie\",\"kind\":\"job\"},{\"title\":\"상생 빛 드림 장학생 추천(~6/7)\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=8927&boardSeq=471379\",\"date\":\"16-06-03\",\"from\":\"ie\",\"kind\":\"scholar\"},{\"title\":\"2016년도 Power Engineering School Summer Camp(제 10기)\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=8927&boardSeq=470954\",\"date\":\"16-05-31\",\"from\":\"ie\",\"kind\":\"scholar\"},{\"title\":\"저학년 진로탐색프로그램 안내\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=8927&boardSeq=468372\",\"date\":\"16-05-12\",\"from\":\"ie\",\"kind\":\"job\"},{\"title\":\"2016학년도 하반기 삼성드림클래스 대학생강사 선발 (면접일정변경) \",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=4741&boardSeq=471747\",\"date\":\"16-06-08\",\"from\":\"stat\",\"kind\":\"scholar\"},{\"title\":\"2016학년도 공교육만족 프로젝트 멘토링 멘토모집\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=4741&boardSeq=471856\",\"date\":\"16-06-09\",\"from\":\"stat\",\"kind\":\"scholar\"},{\"title\":\"2016학년도 2학기 국가근로장학생 신청 안내\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=4741&boardSeq=469944\",\"date\":\"16-05-20\",\"from\":\"stat\",\"kind\":\"scholar\"},{\"title\":\"2016학년도 2학기 휴․복학기간 지정 통보\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=4741&boardSeq=471763\",\"date\":\"16-06-08\",\"from\":\"stat\",\"kind\":\"scholar\"},{\"title\":\"[재학생은 반드시 1차 신청] 2016년도 2학기 한국장학재단 국가장학금 1차 신청\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=4741&boardSeq=469943\",\"date\":\"16-05-20\",\"from\":\"stat\",\"kind\":\"scholar\"},{\"title\":\"2016학년도 하계 계절학기·어학연수 파견 자비유학생 선발\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=4741&boardSeq=468302\",\"date\":\"16-05-11\",\"from\":\"stat\",\"kind\":\"foreign\"},{\"title\":\"2016년 하계방학 중 교외 집중근로 프로그램 참여 신청\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=4741&boardSeq=469235\",\"date\":\"16-05-13\",\"from\":\"stat\",\"kind\":\"scholar\"},{\"title\":\"2016학년도 삼성드림클래스 여름캠프 대학생강사 선발 \",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=4741&boardSeq=469234\",\"date\":\"16-05-13\",\"from\":\"stat\",\"kind\":\"scholar\"},{\"title\":\"[교육부] ‘2016년 대학생 자유학기제 봉사단‘ 모집안내\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=4741&boardSeq=467308\",\"date\":\"16-04-29\",\"from\":\"stat\",\"kind\":\"foreign\"},{\"title\":\"2016.2학기 기초학문진흥사업 해외파견 프로그램 참가자모집\",\"link\":\"http://uwcms.pusan.ac.kr/user/boardList.action?command=view&page=1&boardId=4741&boardSeq=467281\",\"date\":\"16-04-29\",\"from\":\"stat\",\"kind\":\"foreign\"}]";

        try {
            JSONArray jarray = new JSONArray(str);   // JSONArray 생성
            //section_adapter.addSection(divStr);
            for(int i=0; i < jarray.length(); i++) {
                JSONObject jObject = jarray.getJSONObject(i);  // JSONObject 추출
                String title = jObject.getString("title");
                String date = jObject.getString("date");
                String url = jObject.getString("link");
                String from = jObject.getString("from");
                String kind = jObject.getString("kind");

                //db 읽어와서 체크 된 항목만 add 시켜줘야함!!!!!!!!!!!
                if (kind.equalsIgnoreCase("job")) {
                    mChildListContentJob.add(createItem(title,date,from,url));
                }
                else if (kind.equalsIgnoreCase("scholar")) {
                    mChildListContentScholar.add(createItem(title,date,from,url));
                }
                else if (kind.equalsIgnoreCase("foreign")) {
                    mChildListContentForeign.add(createItem(title,date,from,url));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
